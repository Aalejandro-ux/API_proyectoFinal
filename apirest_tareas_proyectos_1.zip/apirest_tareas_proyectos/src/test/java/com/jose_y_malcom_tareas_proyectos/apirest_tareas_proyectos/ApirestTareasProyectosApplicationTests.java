package com.jose_y_malcom_tareas_proyectos.apirest_tareas_proyectos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApirestTareasProyectosApplicationTests {

	@Test
	void contextLoads() {
	}

}
