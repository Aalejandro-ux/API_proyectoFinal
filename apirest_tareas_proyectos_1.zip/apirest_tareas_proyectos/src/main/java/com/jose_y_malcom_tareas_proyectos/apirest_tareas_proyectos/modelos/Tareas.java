package com.jose_y_malcom_tareas_proyectos.apirest_tareas_proyectos.modelos;

import java.io.Serializable;
import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Tareas implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    private Integer ID_tarea;
    private LocalDate fecha_asignamiento;
    private LocalDate fecha_entrega;
    private String estado;

    public Tareas() {
    }

    public Integer getID_tarea() {
        return ID_tarea;
    }

    public void setID_tarea(Integer iD_tarea) {
        ID_tarea = iD_tarea;
    }

    public LocalDate getFecha_asignamiento() {
        return fecha_asignamiento;
    }

    public void setFecha_asignamiento(LocalDate fecha_asignamiento) {
        this.fecha_asignamiento = fecha_asignamiento;
    }

    public LocalDate getFecha_entrega() {
        return fecha_entrega;
    }

    public void setFecha_entrega(LocalDate fecha_entrega) {
        this.fecha_entrega = fecha_entrega;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

}