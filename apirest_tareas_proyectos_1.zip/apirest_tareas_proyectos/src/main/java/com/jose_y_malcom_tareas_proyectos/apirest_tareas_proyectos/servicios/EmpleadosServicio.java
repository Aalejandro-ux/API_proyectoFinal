package com.jose_y_malcom_tareas_proyectos.apirest_tareas_proyectos.servicios;

import java.util.List;

import com.jose_y_malcom_tareas_proyectos.apirest_tareas_proyectos.modelos.Empleados;


public interface EmpleadosServicio {

    public List<Empleados> obtenerTodo();

    public Empleados guardar(Empleados Empleados);

    public Empleados obtenerPorId(Integer id);

    public void eliminar(Integer id);


}