package com.jose_y_malcom_tareas_proyectos.apirest_tareas_proyectos.repositorios;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.jose_y_malcom_tareas_proyectos.apirest_tareas_proyectos.modelos.Empleados;



@Repository
public interface EmpleadosRepositorio extends JpaRepository<Empleados, Integer> {

}