package com.jose_y_malcom_tareas_proyectos.apirest_tareas_proyectos.modelos;

import java.io.Serializable;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Empleados implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    private Integer ID_empleados;
    private String nombre;
    private String direccion;
    private String correo;
    private Integer salario;
    private Integer telefono;

    public Empleados() {
    }

    public Integer getID_empleados() {
        return ID_empleados;
    }

    public void setID_empleados(Integer iD_empleados) {
        ID_empleados = iD_empleados;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public Integer getSalario() {
        return salario;
    }

    public void setSalario(Integer salario) {
        this.salario = salario;
    }

    public Integer getTelefono() {
        return telefono;
    }

    public void setTelefono(Integer telefono) {
        this.telefono = telefono;
    }

    
}