package com.jose_y_malcom_tareas_proyectos.apirest_tareas_proyectos.servicios;

import java.util.List;

import com.jose_y_malcom_tareas_proyectos.apirest_tareas_proyectos.modelos.Proyectos;


public interface ProyectosServicio {

    public List<Proyectos> obtenerTodo();

    public Proyectos guardar(Proyectos proyectos);

    public Proyectos obtenerPorId(Integer id);

    public void eliminar(Integer id);

    String actualizarPresupuestoProyecto(int idProyecto, int monto, String operacion);

}
