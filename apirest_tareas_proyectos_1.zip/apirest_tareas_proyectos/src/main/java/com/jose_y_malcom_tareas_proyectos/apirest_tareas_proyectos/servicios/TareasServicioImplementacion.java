package com.jose_y_malcom_tareas_proyectos.apirest_tareas_proyectos.servicios;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jose_y_malcom_tareas_proyectos.apirest_tareas_proyectos.modelos.Tareas;
import com.jose_y_malcom_tareas_proyectos.apirest_tareas_proyectos.repositorios.TareasRepositorio;

import jakarta.persistence.EntityManager;
import jakarta.persistence.ParameterMode;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.StoredProcedureQuery;

@Service
public class TareasServicioImplementacion implements TareasServicio{

    @PersistenceContext
    public EntityManager entityManager;

    @Autowired
    public
    TareasRepositorio TareasRepositorio;

    @Override
    public List<Tareas> obtenerTodo() {
        return TareasRepositorio.findAll();
    }

    @Override
    public Tareas guardar(Tareas Tareas) {
        // TODO Auto-generated method stub
        return TareasRepositorio.save(Tareas);
    }

    @Override
    public Tareas obtenerPorId(Integer id) {
        // TODO Auto-generated method stub
        return TareasRepositorio.findById(id).orElse(null);
    }

    @Override
    public void eliminar(Integer id) {
        // TODO Auto-generated method stub
        TareasRepositorio.deleteById(id);
    }
    
}