package com.jose_y_malcom_tareas_proyectos.apirest_tareas_proyectos.servicios;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jose_y_malcom_tareas_proyectos.apirest_tareas_proyectos.modelos.Proyectos;
import com.jose_y_malcom_tareas_proyectos.apirest_tareas_proyectos.repositorios.ProyectosRepositorio;

import jakarta.persistence.EntityManager;
import jakarta.persistence.ParameterMode;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.StoredProcedureQuery;

@Service
public class ProyectosServicioImplementacion implements ProyectosServicio{

    @PersistenceContext
    public EntityManager entityManager;

    @Autowired
    public
    ProyectosRepositorio ProyectosRepositorio;

    @Override
    public List<Proyectos> obtenerTodo() {
        return ProyectosRepositorio.findAll();
    }

    @Override
    public Proyectos guardar(Proyectos Proyectos) {
        // TODO Auto-generated method stub
        return ProyectosRepositorio.save(Proyectos);
    }

    @Override
    public Proyectos obtenerPorId(Integer id) {
        // TODO Auto-generated method stub
        return ProyectosRepositorio.findById(id).orElse(null);
    }

    @Override
    public void eliminar(Integer id) {
        // TODO Auto-generated method stub
        ProyectosRepositorio.deleteById(id);
    }

    @Override
    public String actualizarPresupuestoProyecto(int idProyecto, int monto, String operacion) {
        try {
            StoredProcedureQuery query = entityManager.createStoredProcedureQuery("ActualizarPresupuestoProyecto");

            // Registrar parámetros
            query.registerStoredProcedureParameter("p_id_proyecto", Integer.class, ParameterMode.IN);
            query.registerStoredProcedureParameter("p_monto", Integer.class, ParameterMode.IN);
            query.registerStoredProcedureParameter("p_operacion", String.class, ParameterMode.IN);

            // Establecer valores
            query.setParameter("p_id_proyecto", idProyecto);
            query.setParameter("p_monto", monto);
            query.setParameter("p_operacion", operacion);

            // Ejecutar el procedimiento
            Object resultado = query.getSingleResult();

            return resultado.toString();
        } catch (Exception e) {
            return "Error: " + e.getMessage();
        }
    }

    
}