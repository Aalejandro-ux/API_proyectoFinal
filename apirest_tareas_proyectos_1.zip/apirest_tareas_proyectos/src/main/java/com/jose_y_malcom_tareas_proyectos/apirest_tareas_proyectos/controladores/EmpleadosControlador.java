package com.jose_y_malcom_tareas_proyectos.apirest_tareas_proyectos.controladores;

import java.security.PublicKey;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jose_y_malcom_tareas_proyectos.apirest_tareas_proyectos.modelos.Empleados;
import com.jose_y_malcom_tareas_proyectos.apirest_tareas_proyectos.servicios.EmpleadosServicioImplementacion;


@RestController
@RequestMapping("/api")
public class EmpleadosControlador {

    @Autowired
    EmpleadosServicioImplementacion EmpleadosServicio;

    @GetMapping("/empleados")
    public List<Empleados> obtenerEmpleados(){
        return EmpleadosServicio.obtenerTodo();
    }

    @PostMapping("/guardar_empleados")
    public ResponseEntity<Empleados> guardarEmpleados(@RequestBody Empleados Empleados){
        Empleados nuevo_Empleados = EmpleadosServicio.guardar(Empleados);
        return new ResponseEntity<>(nuevo_Empleados, HttpStatus.CREATED);
    }

    @GetMapping("/empleados/{id}")
    public ResponseEntity<Empleados> obtenerEmpleadosId(@PathVariable Integer id){
        Empleados EmpleadosPorId = EmpleadosServicio.obtenerPorId(id);

        return ResponseEntity.ok(EmpleadosPorId);
    }

    @PutMapping("/empleados/{id}")
    public ResponseEntity<Empleados> actualizar(@PathVariable Integer id, @RequestBody Empleados Empleados){
        Empleados EmpleadosPorId = EmpleadosServicio.obtenerPorId(id);
        EmpleadosPorId.setID_empleados(Empleados.getID_empleados());
        EmpleadosPorId.setNombre(Empleados.getNombre());
        EmpleadosPorId.setDireccion(Empleados.getDireccion());
        EmpleadosPorId.setCorreo(Empleados.getCorreo());
        EmpleadosPorId.setSalario(Empleados.getSalario());
        EmpleadosPorId.setTelefono(Empleados.getTelefono());

        Empleados Empleados_actualizados = EmpleadosServicio.guardar(EmpleadosPorId);
        return new ResponseEntity<>(Empleados_actualizados, HttpStatus.CREATED);

    }

    @DeleteMapping("/empleados/{id}")
    public ResponseEntity<HashMap<String, Boolean>> eliminarEmpleados(@PathVariable Integer id){
        this.EmpleadosServicio.eliminar(id);

        HashMap<String, Boolean> estadoEmpleadosEliminados = new HashMap<>();
        estadoEmpleadosEliminados.put("eliminado", true);
        return ResponseEntity.ok(estadoEmpleadosEliminados);
    }

}