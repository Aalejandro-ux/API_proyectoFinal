package com.jose_y_malcom_tareas_proyectos.apirest_tareas_proyectos.servicios;

import java.util.List;

import com.jose_y_malcom_tareas_proyectos.apirest_tareas_proyectos.modelos.Tareas;


public interface TareasServicio {

    public List<Tareas> obtenerTodo();

    public Tareas guardar(Tareas tareas);

    public Tareas obtenerPorId(Integer id);

    public void eliminar(Integer id);


}