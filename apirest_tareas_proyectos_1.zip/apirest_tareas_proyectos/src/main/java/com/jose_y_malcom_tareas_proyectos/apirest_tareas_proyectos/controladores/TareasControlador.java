package com.jose_y_malcom_tareas_proyectos.apirest_tareas_proyectos.controladores;

import java.security.PublicKey;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jose_y_malcom_tareas_proyectos.apirest_tareas_proyectos.modelos.Tareas;
import com.jose_y_malcom_tareas_proyectos.apirest_tareas_proyectos.servicios.TareasServicioImplementacion;


@RestController
@RequestMapping("/api")
public class TareasControlador {

    @Autowired
    TareasServicioImplementacion TareasServicio;

    @GetMapping("/tareas")
    public List<Tareas> obtenerTareas(){
        return TareasServicio.obtenerTodo();
    }

    @PostMapping("/guardar_tareas")
    public ResponseEntity<Tareas> guardarTareas(@RequestBody Tareas Tareas){
        Tareas nuevo_Tareas = TareasServicio.guardar(Tareas);
        return new ResponseEntity<>(nuevo_Tareas, HttpStatus.CREATED);
    }

    @GetMapping("/tareas/{id}")
    public ResponseEntity<Tareas> obtenerTareasId(@PathVariable Integer id){
        Tareas TareasPorId = TareasServicio.obtenerPorId(id);

        return ResponseEntity.ok(TareasPorId);
    }

    @PutMapping("/tareas/{id}")
    public ResponseEntity<Tareas> actualizar(@PathVariable Integer id, @RequestBody Tareas Tareas){
        Tareas TareasPorId = TareasServicio.obtenerPorId(id);
        TareasPorId.setID_tarea(Tareas.getID_tarea());
        TareasPorId.setFecha_asignamiento(Tareas.getFecha_asignamiento());
        TareasPorId.setFecha_entrega(Tareas.getFecha_entrega());
        TareasPorId.setEstado(Tareas.getEstado());

        Tareas Tareas_actualizados = TareasServicio.guardar(TareasPorId);
        return new ResponseEntity<>(Tareas_actualizados, HttpStatus.CREATED);

    }

    @DeleteMapping("/tareas/{id}")
    public ResponseEntity<HashMap<String, Boolean>> eliminarTareas(@PathVariable Integer id){
        this.TareasServicio.eliminar(id);

        HashMap<String, Boolean> estadoTareasEliminados = new HashMap<>();
        estadoTareasEliminados.put("eliminado", true);
        return ResponseEntity.ok(estadoTareasEliminados);
    }

}