package com.jose_y_malcom_tareas_proyectos.apirest_tareas_proyectos.controladores;

import java.security.PublicKey;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jose_y_malcom_tareas_proyectos.apirest_tareas_proyectos.modelos.Proyectos;
import com.jose_y_malcom_tareas_proyectos.apirest_tareas_proyectos.servicios.ProyectosServicioImplementacion;


@RestController
@RequestMapping("/api")
public class ProyectosControlador {

    @Autowired
    ProyectosServicioImplementacion ProyectosServicio;

    @GetMapping("/proyectos")
    public List<Proyectos> obtenerProyectos(){
        return ProyectosServicio.obtenerTodo();
    }

    @PostMapping("/guardar_proyectos")
    public ResponseEntity<Proyectos> guardarProyectos(@RequestBody Proyectos Proyectos){
        Proyectos nuevo_Proyectos = ProyectosServicio.guardar(Proyectos);
        return new ResponseEntity<>(nuevo_Proyectos, HttpStatus.CREATED);
    }

    @GetMapping("/proyectos/{id}")
    public ResponseEntity<Proyectos> obtenerProyectosId(@PathVariable Integer id){
        Proyectos ProyectosPorId = ProyectosServicio.obtenerPorId(id);

        return ResponseEntity.ok(ProyectosPorId);
    }

    @PutMapping("/proyectos/{id}")
    public ResponseEntity<Proyectos> actualizar(@PathVariable Integer id, @RequestBody Proyectos Proyectos){
        Proyectos ProyectosPorId = ProyectosServicio.obtenerPorId(id);
        ProyectosPorId.setID_proyecto(Proyectos.getID_proyecto());
        ProyectosPorId.setFecha_inicio(Proyectos.getFecha_inicio());
        ProyectosPorId.setFecha_final(Proyectos.getFecha_final());
        ProyectosPorId.setDescripcion(Proyectos.getDescripcion());
        ProyectosPorId.setPresupuesto(Proyectos.getPresupuesto());
        ProyectosPorId.setAntiguedad(Proyectos.getAntiguedad());

        Proyectos Proyectos_actualizados = ProyectosServicio.guardar(ProyectosPorId);
        return new ResponseEntity<>(Proyectos_actualizados, HttpStatus.CREATED);

    }

    @DeleteMapping("/proyectos/{id}")
    public ResponseEntity<HashMap<String, Boolean>> eliminarProyectos(@PathVariable Integer id){
        this.ProyectosServicio.eliminar(id);

        HashMap<String, Boolean> estadoProyectosEliminados = new HashMap<>();
        estadoProyectosEliminados.put("eliminado", true);
        return ResponseEntity.ok(estadoProyectosEliminados);
    }

    @PostMapping("/proyectos/actualizar-presupuesto")
    public ResponseEntity<String> actualizarPresupuesto(
            @RequestParam int idProyecto,
            @RequestParam int monto,
            @RequestParam String operacion) {

        String resultado = ProyectosServicio.actualizarPresupuestoProyecto(idProyecto, monto, operacion);
        return ResponseEntity.ok(resultado);
    }


}