package com.jose_y_malcom_tareas_proyectos.apirest_tareas_proyectos.modelos;

import java.io.Serializable;
import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Proyectos implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    private Integer ID_proyecto;
    private LocalDate fecha_inicio;
    private LocalDate fecha_final;
    private String descripcion;
    private Integer presupuesto;
    private Integer antiguedad;

    public Proyectos() {
    }

    public Integer getID_proyecto() {
        return ID_proyecto;
    }

    public void setID_proyecto(Integer iD_proyecto) {
        ID_proyecto = iD_proyecto;
    }

    public LocalDate getFecha_inicio() {
        return fecha_inicio;
    }

    public void setFecha_inicio(LocalDate fecha_inicio) {
        this.fecha_inicio = fecha_inicio;
    }

    public LocalDate getFecha_final() {
        return fecha_final;
    }

    public void setFecha_final(LocalDate fecha_final) {
        this.fecha_final = fecha_final;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Integer getPresupuesto() {
        return presupuesto;
    }

    public void setPresupuesto(Integer presupuesto) {
        this.presupuesto = presupuesto;
    }

    public Integer getAntiguedad() {
        return antiguedad;
    }

    public void setAntiguedad(Integer antiguedad) {
        this.antiguedad = antiguedad;
    }


}