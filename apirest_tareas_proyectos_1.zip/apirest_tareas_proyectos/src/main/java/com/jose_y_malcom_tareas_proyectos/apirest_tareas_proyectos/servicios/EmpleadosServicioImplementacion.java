package com.jose_y_malcom_tareas_proyectos.apirest_tareas_proyectos.servicios;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jose_y_malcom_tareas_proyectos.apirest_tareas_proyectos.modelos.Empleados;
import com.jose_y_malcom_tareas_proyectos.apirest_tareas_proyectos.repositorios.EmpleadosRepositorio;

import jakarta.persistence.EntityManager;
import jakarta.persistence.ParameterMode;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.StoredProcedureQuery;

@Service
public class EmpleadosServicioImplementacion implements EmpleadosServicio{

    @PersistenceContext
    public EntityManager entityManager;

    @Autowired
    public
    EmpleadosRepositorio EmpleadosRepositorio;

    @Override
    public List<Empleados> obtenerTodo() {
        return EmpleadosRepositorio.findAll();
    }

    @Override
    public Empleados guardar(Empleados Empleados) {
        // TODO Auto-generated method stub
        return EmpleadosRepositorio.save(Empleados);
    }

    @Override
    public Empleados obtenerPorId(Integer id) {
        // TODO Auto-generated method stub
        return EmpleadosRepositorio.findById(id).orElse(null);
    }

    @Override
    public void eliminar(Integer id) {
        // TODO Auto-generated method stub
        EmpleadosRepositorio.deleteById(id);
    }
    
}