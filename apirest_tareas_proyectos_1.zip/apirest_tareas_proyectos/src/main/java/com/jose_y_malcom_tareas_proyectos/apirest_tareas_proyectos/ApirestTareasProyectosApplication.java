package com.jose_y_malcom_tareas_proyectos.apirest_tareas_proyectos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApirestTareasProyectosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApirestTareasProyectosApplication.class, args);
	}

}
